    </div> <!-- #page-wrapper-content -->
  </div> <!-- #page-wrapper -->

  <?php include "includes/footer_desktop.php"; ?>
  <?php include "includes/footer_mobile.php"; ?>


  <!-- dependent on (?) -->
  <?php include "includes/script.php" ?>

  <!-- wp-footer -->
  <?php wp_footer(); ?>

</body>
</html>